const axios = require("axios");
const fs = require("fs");

const { retrieve } = require("./retriever");
const { buildContext } = require("./context_builder");

// ── Llamada base a Ollama — texto libre ───────────────────────────────────
async function callOllama(prompt, model = "qwen2.5-coder:7b") {
  const response = await axios.post("http://localhost:11434/api/generate", {
    model,
    prompt,
    stream: false
  });
  return response.data.response;
}

// ── Llamada a Ollama con formato JSON forzado ─────────────────────────────
async function callOllamaJSON(prompt, model = "qwen2.5-coder:7b") {
  const response = await axios.post("http://localhost:11434/api/generate", {
    model,
    prompt,
    stream: false,
    format: "json"
  });
  return response.data.response;
}

// ── Prompt libre ──────────────────────────────────────────────────────────
async function runLLM(prompt, model = "qwen2.5-coder:7b") {
  return callOllama(prompt, model);
}

// ── Architect — genera código GDScript estructurado en JSON ───────────────
async function queryArchitect(task) {
  const readSafe = (p) => {
    try { return fs.readFileSync(p, "utf-8"); } catch { return ""; }
  };

  const godotRules = readSafe("system/godot_rules.md");

  const projectContext = buildContext(task, {
    maxFiles: 3,
    verbose:  false,
    withDeps: false,
  });

  const prompt = [
    "You are a GDScript code generator for Godot 4.",
    "You always respond with a JSON object containing a files array.",
    "",
    "EXAMPLE 1:",
    'Task: "Create scripts/ship.gd with @export var ship_tier: int = 0"',
    'Response: {"files":[{"path":"scripts/ship.gd","action":"create","content":"extends Node2D\\n\\n@export var ship_tier: int = 0\\n\\nfunc _ready() -> void:\\n\\tpass\\n"}]}',
    "",
    "EXAMPLE 2:",
    'Task: "Add func travel_to(island_id: String) to scripts/ship.gd"',
    'Response: {"files":[{"path":"scripts/ship.gd","action":"modify","content":"extends Node2D\\n\\n@export var ship_tier: int = 0\\n\\nfunc _ready() -> void:\\n\\tpass\\n\\nfunc travel_to(island_id: String) -> void:\\n\\tpass\\n"}]}',
    "",
    "EXAMPLE 3:",
    'Task: "Create scripts/hud.gd that shows doblones count"',
    'Response: {"files":[{"path":"scripts/hud.gd","action":"create","content":"extends CanvasLayer\\n\\n@onready var label: Label = $Label\\n\\nfunc _ready() -> void:\\n\\tupdate_display(0)\\n\\nfunc update_display(amount: int) -> void:\\n\\tlabel.text = \\"Doblones: \\" + str(amount)\\n"}]}',
    "",
    "RULES:",
    "- path must be the exact .gd file mentioned in the task",
    "- content must be GDScript 4 as a JSON string",
    "- First line of content must be: extends SomeClass",
    "- Use @export var (never export var)",
    "- Use func (never def or function)",
    "- Every script must have at least one func",
    "",
    "GODOT 4 RULES:",
    godotRules,
    "",
    "PROJECT FILES (reference only):",
    projectContext,
    "",
    "TASK: " + task,
    "",
    "Response:",
  ].join("\n");

  return callOllamaJSON(prompt, "qwen2.5-coder:7b");
}

module.exports = { queryArchitect, runLLM, callOllama, callOllamaJSON };
