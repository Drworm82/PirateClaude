const axios = require("axios");
const fs = require("fs");

const { retrieve } = require("./retriever");
const { buildContext } = require("./context_builder");

// ── Llamada base a Ollama — texto libre ───────────────────────────────────
async function callOllama(prompt, model = "qwen2:7b") {
  const response = await axios.post("http://localhost:11434/api/generate", {
    model,
    prompt,
    stream: false
  });
  return response.data.response;
}

// ── Llamada a Ollama con formato JSON forzado ─────────────────────────────
// Ollama garantiza que el output sea JSON sintácticamente válido.
// El prompt aún debe describir el schema esperado.
async function callOllamaJSON(prompt, model = "qwen2:7b") {
  const response = await axios.post("http://localhost:11434/api/generate", {
    model,
    prompt,
    stream: false,
    format: "json"        // ← fuerza JSON válido a nivel de tokenizer
  });
  return response.data.response;
}

// ── Prompt libre — para diagnóstico, análisis, preguntas abiertas ─────────
async function runLLM(prompt, model = "qwen2:7b") {
  return callOllama(prompt, model);
}

// ── Architect — genera código GDScript estructurado en JSON ───────────────
async function queryArchitect(task) {
  const readSafe = (p) => {
    try { return fs.readFileSync(p, "utf-8"); } catch { return ""; }
  };

  const godotRules    = readSafe("system/godot_rules.md");
  const godotLanguage = readSafe("system/godot_language_rules.md");

  // Contexto reducido — solo 4 archivos para no aplastar la tarea
  const projectContext = buildContext(task, {
    maxFiles: 4,
    verbose:  false,
    withDeps: false,
  });

  const memory = retrieve(task);

  // Prompt ultra-directivo: schema primero, tarea repetida al final
  const prompt = `You are a GDScript code generator for Godot 4.
You receive a TASK and output ONLY a JSON object with the files to create or modify.

OUTPUT FORMAT — respond with EXACTLY this structure, nothing else:
{
  "files": [
    {
      "path": "scripts/filename.gd",
      "action": "create",
      "content": "extends Node\\n\\nfunc _ready() -> void:\\n\\tpass"
    }
  ]
}

RULES:
- "files" must be an array with at least one item
- "path" must end in .gd and match the file mentioned in the TASK
- "content" must be valid GDScript for Godot 4
- Every script needs "extends ClassName" at the top
- Use "@export var" not "export var"
- Use "func" not "def" or "function"
- Use tabs for indentation
- No markdown, no explanation, no text outside the JSON

GODOT 4 SYNTAX RULES:
${godotRules}

${godotLanguage}

EXISTING PROJECT FILES (reference only — do not copy blindly):
${projectContext}

MEMORY:
${memory}

TASK (implement this exactly):
${task}

TASK REMINDER (do not forget the file path):
${task}

JSON:`.trim();

  return callOllamaJSON(prompt, "qwen2:7b");
}

module.exports = { queryArchitect, runLLM, callOllama, callOllamaJSON };
